
public interface Account {

}
